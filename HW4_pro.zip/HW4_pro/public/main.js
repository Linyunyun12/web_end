document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('#quotesTable tbody');
    const resultMsg = document.getElementById('resultMsg');
    const loading = document.getElementById('loadingIndicator');
    const insertForm = document.getElementById('insertForm');
    const sortForm = document.getElementById('sortForm');
    const sortField = document.getElementById('sortField');
    const sortOrder = document.getElementById('sortOrder');
    const chartCanvas = document.getElementById('priceChart');
    let chart = null;

    const filterForm = document.getElementById('filterForm');
    const paginationControls = document.getElementById('paginationControls');
    let currentPage = 1;
    const itemsPerPage = 10;
    let filteredData = [];

    filterForm.addEventListener('submit', e => {
        e.preventDefault();
        currentPage = 1;
        applyFilters();
    });

    function applyFilters() {
        const start = document.getElementById('startDate').value;
        const end = document.getElementById('endDate').value;
        const min = parseFloat(document.getElementById('minPrice').value);
        const max = parseFloat(document.getElementById('maxPrice').value);

        let result = allData;

        if (start)
            result = result.filter(r => new Date(r.date_time) >= new Date(start));
        if (end)
            result = result.filter(r => new Date(r.date_time) <= new Date(end));
        if (!isNaN(min))
            result = result.filter(r => r.price >= min);
        if (!isNaN(max))
            result = result.filter(r => r.price <= max);

        filteredData = result;
        renderPage(currentPage);
        renderChart(filteredData);
    }

    function renderPage(page) {
        const startIndex = (page - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const pageData = filteredData.slice(startIndex, endIndex);

        let prevPrice = null;
        if (startIndex > 0) {
            prevPrice = filteredData[startIndex - 1].price;
        } else if (filteredData.length > 1) {
            // 第一頁時，讓最新一筆和第二筆比較
            prevPrice = filteredData[1].price;
        }
        renderTable(pageData, prevPrice);
        renderPagination(filteredData.length, page);
    }

    function renderPagination(totalItems, currentPage) {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        let html = '';

        if (currentPage > 1) {
            html += `<button data-page="${currentPage - 1}">上一頁</button>`;
        }

        for (let i = 1; i <= totalPages; i++) {
            html += `<button data-page="${i}" ${i === currentPage ? 'disabled' : ''}>${i}</button>`;
        }

        if (currentPage < totalPages) {
            html += `<button data-page="${currentPage + 1}">下一頁</button>`;
        }

        paginationControls.innerHTML = html;
        paginationControls.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                currentPage = parseInt(btn.dataset.page);
                renderPage(currentPage);
            });
        });
    }

    const resetBtn = document.getElementById('resetBtn');

    resetBtn.addEventListener('click', () => {
        // 清空輸入欄位
        document.getElementById('startDate').value = '';
        document.getElementById('endDate').value = '';
        document.getElementById('minPrice').value = '';
        document.getElementById('maxPrice').value = '';
        currentPage = 1;
        filteredData = allData;
        renderPage(currentPage);
        renderChart(filteredData);
    });


    function showLoading(show) {
        loading.style.display = show ? 'block' : 'none';
    }

    let allData = [];

    async function loadQuotes(sort = 'date_time', order = 'DESC') {
        showLoading(true);
        try {
            const res = await fetch(`/api/quotes?sort=${sort}&order=${order}`);
            const data = await res.json();
            showLoading(false);
            allData = data;
            console.log('allData', allData);
            applyFilters(); // 套用篩選與分頁
        } catch (err) {
            showLoading(false);
            resultMsg.textContent = '載入失敗：' + err.message;
        }
    }

    function renderTable(data, prevPrice = null) {
        tableBody.innerHTML = '';
        const isDesc = sortOrder.value === 'DESC';
        let prevRow = null;
        let prevRowPrice = prevPrice;

        data.forEach((row, idx) => {
            const dateObj = new Date(row.date_time);
            const dateStr = !isNaN(dateObj)
                ? `${dateObj.getFullYear()}年${String(dateObj.getMonth() + 1).padStart(2, '0')}月${String(dateObj.getDate()).padStart(2, '0')}日`
                : row.date_time;

            const isUserAdded = row.is_user_added === 'true';
            const tr = document.createElement('tr');
            tr.dataset.id = row.id;
            tr.dataset.isUserAdded = isUserAdded;
            let diff = '—';

            if (idx > 0 || prevPrice !== null) {
                let d;
                if (isDesc) {
                    d = prevRowPrice - row.price;
                } else {
                    d = row.price - prevRowPrice;
                }
                if (d > 0) diff = `<span style="color:#d72631;font-weight:bold">&uarr;${d}</span>`;
                else if (d < 0) diff = `<span style="color:#219150;font-weight:bold">&darr;${Math.abs(d)}</span>`;
            }

            tr.innerHTML = `
            <td>${row.id}</td>
            <td>${dateStr}</td>
            <td>${row.price}</td>
            <td>${diff}</td>
            <td><button data-id="${row.id}" class="delete-btn">刪除</button></td>
        `;

            // 帳跌顯示「上移」
            if (isDesc && prevRow) {
                prevRow.querySelector('td:nth-child(4)').innerHTML = diff;
            } else if (!isDesc) {
                tr.querySelector('td:nth-child(4)').innerHTML = diff;
            }

            tableBody.appendChild(tr);
            prevRow = tr;
            prevRowPrice = row.price;
        });

        // 只有在「第一頁且沒有 prevPrice」時才顯示 `—`
        if (isDesc && tableBody.firstChild && prevPrice === null) {
            tableBody.firstChild.querySelector('td:nth-child(4)').innerHTML = '—';
        }

        // 綁定刪除按鈕
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.dataset.id;
                fetch(`/api/quotes/${id}`, { method: 'DELETE' })
                    .then(res => res.text())
                    .then(msg => {
                        resultMsg.textContent = msg;
                        loadQuotes(sortField.value, sortOrder.value);
                    });
            });
        });
    }

    insertForm.addEventListener('submit', e => {
        e.preventDefault();
        const date_time = document.getElementById('date_time').value;
        const price = document.getElementById('price').value;
        fetch('/api/insert', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ date_time, price })
        })
            .then(res => res.text())
            .then(msg => {
                resultMsg.textContent = msg;
                insertForm.reset();
                loadQuotes(sortField.value, sortOrder.value);
            });
    });

    sortForm.addEventListener('submit', e => {
        e.preventDefault();
        loadQuotes(sortField.value, sortOrder.value);
    });


    function renderChart(data) {
        const ctx = document.getElementById('priceChart').getContext('2d');
        const labels = data.map(row => new Date(row.date_time).toLocaleDateString());
        const prices = data.map(row => row.price);

        if (window.priceChartInstance) {
            window.priceChartInstance.destroy();
        }

        window.priceChartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: '價格趨勢',
                    data: prices,
                    borderColor: '#233f81',
                    backgroundColor: 'rgba(35,63,129,0.57)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false,
                        labels: {
                            font: {
                                family: 'Microsoft JhengHei', // 字體名稱，可改為你要的字體
                                size: 18,                     // 字體大小（可調整）
                                weight: 'bold',
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: '日期',
                            font: {
                                family: 'Noto Sans TC',
                                size: 18,
                                weight: 'bold',
                            }
                        },
                        ticks: {
                            font: {
                                family: 'Microsoft JhengHei',
                                size: 12
                            }
                        }
                    },
                    y: {
                        min: 1300,       // Y 軸最小值，例如 0 元
                        max: 1800,
                        title: {
                            display: true,
                            text: '價格 (元)',
                            font: {
                                family: 'Noto Sans TC',
                                size: 18,
                                weight: 'bold',
                            }
                        },
                        ticks: {
                            font: {
                                family: 'Microsoft JhengHei',
                                size: 14
                            }
                        }
                    }
                }
            }

        });
    }

     loadQuotes(); // 初始載入
});

// 目錄藍
let lastScrollY = window.scrollY;
const header = document.querySelector("header");

window.addEventListener("scroll", () => {
    if (window.scrollY < lastScrollY) {
        // 滑鼠往上
        header.classList.remove("hide");
    } else {
        // 滑鼠往下
        header.classList.add("hide");
    }
    lastScrollY = window.scrollY;
});


// 功能表
document.addEventListener("DOMContentLoaded", function () {
    const tabButtons = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");

    tabButtons.forEach((btn) => {
        btn.addEventListener("click", () => {
            // 移除其他按鈕的 active
            tabButtons.forEach((b) => b.classList.remove("active"));
            // 隱藏所有內容
            tabContents.forEach((c) => c.style.display = "none");

            // 設定目前按鈕 active 並顯示對應內容
            btn.classList.add("active");
            document.getElementById(btn.dataset.target).style.display = "block";
        });
    });
});
